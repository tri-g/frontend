import { Component, OnInit,Input } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { PersonaService } from '../persona.service';
import {Demographics} from "./../demo";
import { ResultModel } from './../result-model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
 public message:any;
 public CategoryModel: ResultModel[];
  public id:any;


constructor(private pservice:PersonaService){ 
  }
  ngOnInit() {
      this.message=this.pservice.readMessage();
      console.log("hey im here!!");
      console.log(this.message);  
      for(let details of this.message){
     this.id=details.client_id;
     }  
  }
  onSubmit(){
  }


  

}